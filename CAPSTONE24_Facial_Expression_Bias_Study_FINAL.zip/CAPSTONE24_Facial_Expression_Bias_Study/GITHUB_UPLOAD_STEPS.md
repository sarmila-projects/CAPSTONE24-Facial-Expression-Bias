# Upload this finished project to your existing GitHub repository

Repository name: `CAPSTONE24-Facial-Expression-Bias`

## Easiest method (browser, no Git commands)
1. Download and extract this ZIP on your computer.
2. Open your repository on GitHub.
3. Click **Add file → Upload files**.
4. Drag the *contents* of the extracted `CAPSTONE24_Facial_Expression_Bias_Study` folder into the upload area (README.md, notebook, report, presentation, ETHICS.md, etc.).
5. Do **not** upload the FER-2013 dataset ZIP or image files.
6. At the bottom, enter commit message: `Complete facial expression dataset bias study`.
7. Click **Commit changes**.

If files already exist, GitHub may ask you to replace them. Check the file names before committing. Uploading through the browser publishes the files to the repository; no terminal commands are needed.

## Important
This ZIP contains project code and documentation, not the dataset itself. The report transparently records preliminary baseline outputs and convergence warnings. Re-run the notebook and update the report if your final model run produces different metrics.
