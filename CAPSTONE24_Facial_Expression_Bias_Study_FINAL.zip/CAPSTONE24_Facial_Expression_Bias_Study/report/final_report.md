# CAPSTONE 24 — Facial Expression Classification: Dataset Bias Study

## 1. Research question
How do dataset composition and image conditions relate to a facial-expression classifier's performance, and why should results be interpreted cautiously?

## 2. Dataset and method
The project used the FER-2013 dataset downloaded from Kaggle (https://www.kaggle.com/datasets/msambare/fer2013). The images were organized into the seven annotated categories angry, disgust, fear, happy, neutral, sad, and surprise. Images are 48×48 grayscale. The observed training split contained 28,709 images and the test split contained 7,178 images.

The training split was imbalanced: happy had 7,215 images and disgust had 436, a ratio of about 16.5:1. A simple Logistic Regression baseline was evaluated on the provided test split. A second experiment used feature standardization and class weighting. These are baseline experiments rather than a comprehensive benchmark.

## 3. Findings
### Dataset composition
The class counts show substantial imbalance. A classifier trained on such data may learn patterns that favor common classes, and overall accuracy can hide poor performance on less represented classes. Class imbalance is an observed property of this dataset; it is not, by itself, proof of demographic or cultural bias.

### Baseline model performance
The unweighted Logistic Regression baseline achieved 37.02% test accuracy. Class-wise recall was 0.66 for happy and 0.05 for disgust, indicating that the model missed many examples in the minority disgust class. In a second StandardScaler + class-weight-balanced Logistic Regression run, accuracy was 30.93% and disgust recall increased to 0.42. This illustrates a trade-off: weighting classes can improve a minority class metric while reducing overall accuracy. Both experiments produced convergence warnings, so the numeric results should be considered preliminary and re-evaluated with a converged model and reproducible settings.

### Image conditions
Images were 48×48 grayscale, limiting fine detail. A rough Laplacian-variance check on 100 sampled images per class gave mean values: angry 2344.81, disgust 2018.47, fear 2101.54, happy 2219.30, neutral 2053.78, sad 1913.67, surprise 2595.98. This metric reflects high-frequency image detail and is sensitive to edges and content; it is not a definitive blur score and does not establish that one class has better images. A larger, controlled image-quality audit would be needed.

## 4. Three verified observations from this experiment
1. The observed training split contains 28,709 images and the observed test split contains 7,178 images (counted from the extracted folder structure).
2. The training class counts range from 436 disgust images to 7,215 happy images (counted from the extracted training folders).
3. The recorded baseline runs reported 37.02% and 30.93% test accuracy respectively, with convergence warnings; these are outputs from this project run, not independent validation or universal performance estimates.

## 5. Limitations and potential bias
- Dataset labels represent annotators' visible-expression categories, not a verified person's internal emotional state.
- The available folder structure does not provide verified demographic or cultural subgroup metadata. Therefore this project does not claim demographic fairness or compare performance across protected groups.
- The provided split may contain images of the same identity across train and test. Without identity metadata, identity-disjoint evaluation cannot be claimed.
- The classifier is a simple baseline and the training runs emitted convergence warnings.
- Image-detail scores were computed on a limited sample and should not be interpreted as definitive quality labels.
- The dataset's sampling, annotation process, context, and label ambiguity may affect the results. Cultural variation in expression and annotation is not measured in this project.
- The Kaggle distribution should be checked against its source documentation and current terms before reuse or redistribution.

## 6. Conclusion
The experiment demonstrates why class counts and per-class metrics should be reported alongside accuracy. The minority class had notably poor recall in the unweighted baseline, while class weighting changed the trade-off. However, this limited audit cannot establish demographic fairness, infer internal emotions, or support real-world deployment. Results should be treated as educational and preliminary.

## 7. Future work
1. Re-run training with a converged solver and fixed random seeds; log software versions and full parameters.
2. Add a confusion matrix, macro-F1, balanced accuracy, and per-class precision/recall to the notebook.
3. If permitted, use documented identity metadata to create identity-grouped splits.
4. Perform controlled image-condition sensitivity tests (e.g., brightness, mild blur, and resizing) and report changes without claiming they represent real-world populations.
5. Review dataset documentation, annotation process, consent, license, and known limitations with original sources.

## 8. Ethics and non-deployment statement
This project is for educational dataset auditing only. It must not be used to make consequential decisions about people or to infer actual emotions, intentions, personality, honesty, or mental state. No deployment is proposed.

## Source
- FER-2013 Kaggle distribution used for this project: https://www.kaggle.com/datasets/msambare/fer2013
- The report's numeric findings are derived from this project's observed folder counts and recorded notebook outputs. They are not claims taken from the Kaggle page.
