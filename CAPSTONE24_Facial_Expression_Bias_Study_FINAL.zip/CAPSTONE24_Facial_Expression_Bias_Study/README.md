# CAPSTONE 24 — Facial Expression Classification: Dataset Bias Study

## Project goal
Study how class imbalance and low-resolution image conditions relate to the performance of a simple facial-expression image classifier. This is a **dataset-bias and model-evaluation exercise**, not a tool for detecting a person's true or inner emotional state.

## Dataset
This project was explored with the FER-2013 dataset obtained from Kaggle: https://www.kaggle.com/datasets/msambare/fer2013

The notebook expects the extracted folder structure:

```text
/content/fer2013/
├── train/<class_name>/*.jpg
└── test/<class_name>/*.jpg
```

Expected labels: `angry`, `disgust`, `fear`, `happy`, `neutral`, `sad`, `surprise`. Images are 48×48 grayscale. Check the dataset's current license/terms and source documentation before redistributing or using it. **Do not commit dataset images or the ZIP to GitHub.**

## Current dataset audit
| Split | Images |
|---|---:|
| Train | 28,709 |
| Test | 7,178 |

| Class | Train | Test |
|---|---:|---:|
| angry | 3,995 | 958 |
| disgust | 436 | 111 |
| fear | 4,097 | 1,024 |
| happy | 7,215 | 1,774 |
| neutral | 4,965 | 1,233 |
| sad | 4,830 | 1,247 |
| surprise | 3,171 | 831 |

The largest training class (`happy`, 7,215) is about 16.5 times the smallest (`disgust`, 436). This is a clear class-count imbalance; it does not by itself prove any demographic or cultural bias.

## Baseline results recorded during the project
A basic Logistic Regression baseline without class weighting reached **37.02% accuracy** on the provided test split. Its reported recall for `disgust` was **0.05**, versus **0.66** for `happy`. A StandardScaler + class-weight-balanced Logistic Regression experiment reached **30.93% accuracy**; `disgust` recall rose to **0.42**, while overall accuracy fell. Both runs reported convergence warnings, so these are preliminary observations, not final optimized performance claims. Re-run the notebook in your environment to reproduce and update the results.

## Run the notebook
1. Open `notebook/bias_audit.ipynb` in Google Colab.
2. Upload the FER-2013 ZIP to the Colab session and extract it to `/content/fer2013` (or change the path in the notebook).
3. Run cells from top to bottom. If Colab resets, variables and files in `/content` may need to be recreated/re-uploaded.
4. Save a copy of the notebook and export key outputs for your report.

Install packages locally with `pip install -r requirements.txt`.

## Project contents
- `notebook/bias_audit.ipynb` — audit and baseline notebook
- `data/manifest_template.csv` — dataset/source documentation template; do not add private information
- `report/final_report.md` — report with recorded results and limitations
- `presentation/project_presentation.md` — presentation outline
- `ETHICS.md` — ethics and non-deployment statement

## Limitations
- The FER-2013 labels are dataset annotations, not ground truth for internal emotional states.
- The supplied train/test split may not be identity-disjoint; identity-grouped evaluation cannot be claimed without reliable identity metadata.
- No demographic subgroup fairness conclusion is made because verified subgroup metadata and a suitable evaluation design were not established.
- The rough Laplacian-variance image-detail check was run on a sample of 100 images per class. It is only a proxy for high-frequency detail, not a definitive blur or image-quality measure.
- The baseline showed convergence warnings and should be treated as preliminary.

## Intended use
Educational research only. Do not use for hiring, discipline, education decisions, healthcare, policing, surveillance, or other consequential decisions. Do not infer personality, intent, truthfulness, or actual feelings from model outputs.
