# Ethics and Non-Deployment Statement

This is a classroom research exercise about dataset composition and the limitations of image classifiers. The model predicts dataset-provided visible-expression labels; it does not determine a person's true feelings or internal emotional state.

- Do not deploy this model in real-world settings.
- Do not use outputs for hiring, education, healthcare, policing, discipline, surveillance, or any other consequential decision.
- Do not infer identity, personality, intent, honesty, or mental health from predictions.
- Do not claim demographic or cultural fairness without verified metadata and a suitable, documented evaluation design.
- Review the dataset's original documentation, license, consent information, and terms before reuse.
- Do not commit the dataset ZIP or image files to this repository.
