# CAPSTONE 24 — Facial Expression Classification: Dataset Bias Study

## Project purpose
This is a reproducible, limitations-first study of how dataset composition and image conditions affect a facial-expression image classifier. It is **not** a detector of a person's inner emotions.

## Important dataset choice and access
Recommended dataset to investigate: **Extended Cohn–Kanade (CK+)**. The official distributor provides a user agreement requiring non-commercial research use, citation, and no redistribution. Review the current terms and obtain access/approval before downloading or using the data:
https://ckplus.jeffcohn.net/request

The official page's agreement is not a blanket permission to redistribute the images. Do not upload faces, dataset archives, or example images to public notebooks/repos. Keep the data local or in an institution-approved private workspace.

CK+ is a controlled, posed dataset and does not represent everyday spontaneous expressions. Its expression labels are not ground truth for internal feelings. It has limited diversity and image conditions; if there is no reliable metadata for a subgroup or condition, report that subgroup comparison as unavailable rather than guessing from images.

**Do not use FER-2013 as a substitute without checking its rules and consent/provenance limitations.** Public availability alone does not establish documented consent or broad reuse rights.

## Files
- `notebook/bias_audit.ipynb`: analysis notebook. Uses a local manifest CSV so it does not assume a particular archive layout.
- `report/final_report_template.md`: report with methodology, result tables to fill after running, ethics and limitations.
- `presentation/project_presentation.md`: slide-by-slide presentation outline.
- `data/manifest_template.csv`: schema for the manifest.
- `requirements.txt`: free Python packages.

## Start here (beginner-friendly)
1. Read the dataset's official documentation and user agreement. Ask your faculty supervisor to approve the dataset and intended use.
2. Download data only through the official process and keep it private.
3. Create `data/manifest.csv` with one row per image:
   - `image_path`: path to image file, relative to this project folder or absolute
   - `label`: documented expression class label
   - `subject_id`: subject identifier from the dataset documentation
   - `condition`: documented image-condition category, if supplied; otherwise leave blank
   - `subgroup`: documented, ethically appropriate subgroup category, if supplied; otherwise leave blank
4. Do not infer age, gender, race/ethnicity, or any sensitive trait by looking at images. Do not create demographic labels from faces.
5. Open the notebook in Google Colab or Jupyter. For Colab, upload the notebook and provide data only in a private, approved environment. Follow dataset terms.
6. Run cells top-to-bottom. Record actual outputs; do not invent results. If there are too few subjects per class, use fewer folds or report that evaluation is not statistically stable.
7. Keep the error gallery private; do not publish face images. In the report, prefer aggregate error descriptions or redacted examples where permission allows.

## Reproducibility note
The notebook is designed for a manifest-based workflow and uses subject-grouped train/test splitting to reduce identity leakage. If your dataset license does not permit the planned processing, visualization, or storage, do not proceed.
