# CAPSTONE 24 — Facial Expression Classification: Dataset Bias Study

**Student:** [Your name]  
**Department / College:** [Your department / college]  
**Course:** CAPSTONE 24  
**Date:** [Submission date]

## Abstract
This project studies how dataset composition and image conditions influence a simple facial-expression image classifier. It treats labels as dataset annotations of visible expressions, not as reliable measurements of a person's internal emotional state. A subject-grouped held-out evaluation, class-wise metrics, confusion analysis, and controlled image perturbations are used. Results are reported only after the notebook is run on a dataset whose access and use terms have been reviewed.

## 1. Research question and objectives
**Question:** How do dataset composition and image conditions affect facial-expression classifier performance, and why should results be interpreted cautiously?

Objectives:
- Audit dataset documentation, consent/access conditions, label definitions, and limitations.
- Quantify class balance and available documented metadata.
- Reduce identity leakage through subject-grouped splitting.
- Report class-wise metrics and confusion patterns.
- Test sensitivity to controlled brightness, contrast, and blur changes.
- Discuss ethics, cultural variation, ambiguity, consent, and non-deployment.

## 2. Dataset documentation review
**Dataset considered:** Extended Cohn–Kanade (CK+), subject to official access approval.  
**Official source:** https://ckplus.jeffcohn.net/request

The official distribution page provides a user agreement for non-commercial research and places restrictions on redistribution. Before using the dataset, the researcher must read and accept the current terms, follow any access process, and verify that the planned educational use is permitted. Dataset images must not be redistributed or uploaded to a public repository. Record the version/date accessed and faculty approval if required.

**Label interpretation:** The categories are dataset annotations for facial-expression analysis. They are not direct ground truth for a person's inner emotion. Expression categories can be ambiguous and affected by context, culture, pose, and annotator choices.

**Known limitations to discuss:** CK+ is a controlled, posed dataset; its conditions may not resemble spontaneous everyday expressions. It is comparatively small, and the available subjects and recording conditions do not represent all populations or environments. Any demographic or condition comparison is limited to documented, permitted metadata. Do not infer sensitive traits by visual inspection.

## 3. Tools and skills
Free tools used/planned:
1. Python — reproducible analysis.
2. pandas — manifest handling and dataset audits.
3. scikit-learn — baseline classifier and evaluation.
4. Jupyter Notebook / Google Colab — experiment workflow (use a private, approved workspace).
5. Pillow — controlled image-condition perturbations.
6. Matplotlib — class balance, confusion matrix, and metric plots.
7. Free research tools / official dataset documentation — source review and verification.

Skills: dataset auditing, image classification basics, train/test leakage prevention, class-wise evaluation, subgroup evaluation where appropriate, error analysis, research ethics, reproducibility, and careful interpretation.

## 4. Methodology
1. Review official documentation and usage terms before processing data.
2. Create a manifest with image path, dataset label, subject ID, and optional documented condition/subgroup fields.
3. Audit missing files, class balance, number of subjects, and images per subject.
4. Resize images to grayscale 48×48 and extract Histogram of Oriented Gradients (HOG) features.
5. Train a class-weighted linear Support Vector Machine (SVM).
6. Use a subject-grouped 75/25 train/test split; verify that subjects do not overlap.
7. Report accuracy, balanced accuracy, precision, recall, F1, and confusion matrix.
8. Apply controlled darker, lower-contrast, and blurred versions to held-out images and compare metrics.
9. Evaluate documented subgroups only when appropriate metadata and adequate sample sizes are available.
10. Keep any image error gallery private and within dataset terms.

## 5. Results
**Important:** Complete this section using the actual notebook output. Do not invent or estimate scores.

| Measure | Result |
|---|---:|
| Number of images after quality checks | [fill from notebook] |
| Number of unique subjects | [fill] |
| Number of classes | [fill] |
| Train/test subject counts | [fill] |
| Held-out accuracy | [fill] |
| Held-out balanced accuracy | [fill] |

### Class-wise performance
Insert the actual precision, recall, F1-score, and support table exported as `outputs/class_wise_report.csv`. Explain which classes have the lowest recall and which categories are most often confused.

### Image-condition sensitivity
Insert the actual values from `outputs/condition_sensitivity.csv`.

| Condition | Accuracy | Balanced accuracy | Interpretation |
|---|---:|---:|---|
| Original | [fill] | [fill] | Baseline |
| Darker | [fill] | [fill] | Controlled stress test only |
| Lower contrast | [fill] | [fill] | Controlled stress test only |
| Blur | [fill] | [fill] | Controlled stress test only |

### Subgroup evaluation
[Report documented condition/subgroup results with sample sizes, or state clearly that such metadata was unavailable or insufficient. Never infer demographic labels from images.]

## 6. Discussion
Performance may differ by class because classes have unequal sample counts, labels overlap visually, and some expressions may be more consistently represented than others. Accuracy alone can conceal poor performance on minority classes, so balanced accuracy and class-wise recall are important. A subject-grouped split gives a more cautious estimate than splitting images randomly, because multiple images of one person can share identity-specific characteristics.

Synthetic image perturbations can show that a model's predictions are sensitive to selected changes in brightness, contrast, or blur. They do not prove how the model will perform in all real-world settings, nor do they reproduce all lighting, camera, pose, occlusion, or cultural differences. A small dataset or small subgroup cannot support broad claims.

Facial movement is not a transparent or universal readout of inner emotion. Labels can be ambiguous, culturally variable, and dependent on annotator assumptions and the context in which images were recorded. Consent for one research purpose does not imply consent for surveillance, profiling, or consequential decisions.

## 7. Limitations
- The dataset is limited in size, population, and capture conditions.
- Posed expressions may not generalize to spontaneous behaviour.
- Labels are annotations, not verified internal emotional states.
- Available metadata may not support robust demographic or image-condition comparisons.
- A single train/test split can vary; future work should use grouped cross-validation where feasible.
- HOG + linear SVM is a simple baseline, not a state-of-the-art model.
- Synthetic perturbations are narrow and cannot establish real-world robustness.
- Access and consent conditions restrict what can be displayed, stored, or shared.

## 8. Ethics and non-deployment statement
This project is an educational dataset-bias and evaluation study only. The model must not be deployed on real people or used for surveillance, hiring, discipline, grading, access control, or other consequential decisions. The model must not be described as reliably detecting inner emotions. Dataset images and identifiable error examples will not be publicly redistributed. Any analysis of subgroup metadata will use only documented and permitted fields and will report sample sizes and uncertainty.

## 9. Conclusion
The study demonstrates a responsible workflow for auditing class balance, reducing identity leakage, examining class-wise errors, and testing selected image-condition changes. Any observed performance is conditional on the dataset, labels, split, and experimental settings. It must not be interpreted as evidence that facial expressions reliably reveal a person's inner state or that the model is appropriate for real-world decision-making.

## 10. Reproducibility notes
- Python version: [fill]
- Package versions: [fill]
- Dataset name/version and access date: [fill]
- Dataset agreement reviewed: [yes/no]
- Random seed: 42
- Split method: GroupShuffleSplit by subject ID
- Feature extractor: HOG, 48×48 grayscale images
- Baseline: class-weighted linear SVM
- Output files: `overall_metrics.csv`, `class_wise_report.csv`, `condition_sensitivity.csv`

## References
1. Extended Cohn–Kanade (CK+) official access page and user agreement: https://ckplus.jeffcohn.net/request
2. Lucey, P. et al. (2010). *The Extended Cohn-Kanade Dataset (CK+): A complete expression dataset for action unit and emotion-specified expression.* CVPR Workshops.
3. Kanade, T., Cohn, J. F., & Tian, Y. (2000). *Comprehensive database for facial expression analysis.* IEEE International Conference on Automatic Face and Gesture Recognition.
4. Barrett, L. F. et al. (2019). *Emotional Expressions Reconsidered: Challenges to Inferring Emotion From Human Facial Movements.* Psychological Science in the Public Interest. https://doi.org/10.1177/1529100619832930
5. Dataset documentation and usage agreement reviewed by the project team: [add access date and version].
