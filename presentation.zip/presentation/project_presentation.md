# CAPSTONE 24 Presentation — Facial Expression Classification: Dataset Bias Study

## Slide 1 — Title
**CAPSTONE 24: Facial Expression Classification — Dataset Bias Study**  
Research question: How do dataset composition and image conditions affect classifier performance, and why should results be interpreted cautiously?

## Slide 2 — Problem statement
- Image classifiers learn patterns in the dataset, not human feelings.
- Imbalanced labels and controlled capture conditions can distort reported performance.
- The goal is a bias/evaluation study, not a real-world emotion detector.

## Slide 3 — Dataset review
- Dataset considered: Extended Cohn–Kanade (CK+), only after reviewing current official access terms and receiving required approval.
- Official terms: https://ckplus.jeffcohn.net/request
- Non-commercial research restrictions and limits on redistribution apply.
- Posed, controlled expressions limit real-world generalization.

## Slide 4 — Tools and skills
- Python, pandas, scikit-learn, Jupyter/Colab, Pillow, Matplotlib.
- Dataset audit, HOG features, linear SVM, grouped split, confusion matrix, subgroup evaluation where appropriate, ethics and reproducibility.

## Slide 5 — Dataset audit
Insert actual class-count chart and image/subject counts from notebook.
Discuss missing images, imbalance, and availability (or absence) of documented metadata.

## Slide 6 — Method
- Manifest records image path, label, subject ID, and only documented optional metadata.
- 48×48 grayscale images; HOG features.
- Class-weighted linear SVM baseline.
- Subject-grouped train/test split to reduce identity leakage.

## Slide 7 — Held-out evaluation
Insert actual accuracy, balanced accuracy, class-wise precision/recall/F1, and confusion matrix.
Explain why accuracy alone can hide weak minority-class performance.

## Slide 8 — Image-condition sensitivity
Insert actual results for original, darker, lower-contrast, and blurred test images.
Explain that these are controlled stress tests, not proof of real-world robustness.

## Slide 9 — Error analysis and subgroup comparison
- Discuss most frequent confusions using aggregate results.
- Compare only documented, permitted subgroups/conditions with adequate sample sizes.
- If metadata is absent, state that a valid subgroup comparison was not possible.
- Do not infer sensitive traits from images.

## Slide 10 — Ethics and limitations
- Expression labels are not ground truth for inner emotion.
- Culture, context, ambiguity, consent, and dataset composition matter.
- Do not publish identifiable face images or redistribute the dataset.
- Do not deploy on real people.

## Slide 11 — Conclusion
- Performance depends on labels, class balance, identity split, and image conditions.
- Results are conditional on this dataset and protocol.
- No claim that facial expressions reliably reveal inner emotion.

## Slide 12 — References
- CK+ official distribution/EULA: https://ckplus.jeffcohn.net/request
- Lucey et al. (2010), CK+ dataset paper.
- Kanade, Cohn & Tian (2000), facial expression database.
- Barrett et al. (2019), *Emotional Expressions Reconsidered*, https://doi.org/10.1177/1529100619832930

**Before presenting:** replace all placeholders with real notebook results. Never fabricate metrics.
